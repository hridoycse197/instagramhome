# Flutter Instagram Feed UI Redesign

[YouTube Speed Code](https://youtu.be/WYL66RNZpDI)

[Design Credit](https://dribbble.com/shots/6349659-Instagram-redesign-concept/attachments)
